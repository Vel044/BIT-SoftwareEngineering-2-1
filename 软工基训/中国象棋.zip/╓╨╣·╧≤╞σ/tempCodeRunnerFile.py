        if game_screen.end_game():
