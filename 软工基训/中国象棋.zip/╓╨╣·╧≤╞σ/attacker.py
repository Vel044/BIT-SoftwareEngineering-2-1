# 导入pygame和copy用于深拷贝
# import pygame


# 导入宏定义和
from start_and_setting import *
from game_screen import *


class Player:
    RED = 1
    BLACK = 2


class Attacker:
    def __init__(self, player, address) -> None:
        self.player = player
        self.address = address

    def move(self, address):
        self.address = address

    def get_player(self):
        return self.player


class Chariot(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_chariot.png"
        else:
            self.image = "./images/red_chariot.png"

    def potential_moves(self, map):
        moves = []
        i = self.address[0]
        j = self.address[1]
        # 向下走
        t = 1
        while (i + t) <= 9:         #棋子还在棋盘上
            if not map[i + t][j]:
                #移动的位置无棋子
                moves.append((i + t, j))
            elif map[i + t][j].player != self.player:
                #是对方棋子可以直接吃
                moves.append((i + t, j))
                break
            else:
                break
            t += 1

        # 向上走
        t = 1
        while (i - t) >= 0:
            if not map[i - t][j]:
                moves.append((i - t, j))
            elif map[i - t][j].player != self.player:
                moves.append((i - t, j))
                break
            else:
                break
            t += 1

        # 向右走
        t = 1
        while (j + t) <= 8:
            if not map[i][j + t]:
                moves.append((i, j + t))
            elif map[i][j + t].player != self.player:
                moves.append((i, j + t))
                break
            else:
                break
            t += 1

        # 向左走
        t = 1
        while (j - t) >= 0:
            if not map[i][j - t]:
                moves.append((i, j - t))
            elif map[i][j - t].player != self.player:
                moves.append((i, j - t))
                break
            else:
                break
            t += 1

        return moves


class Horse(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_horse.png"
        else:
            self.image = "./images/red_horse.png"

    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]
        moves = []

        potential_horse_moves = []
        if (i - 2) >= 0 and not map[i - 1][j]: #not map[][]是判断有无绊马脚
            if (j - 1) >= 0:
                potential_horse_moves.append((i - 2, j - 1))
            if (j + 1) <= 8:
                potential_horse_moves.append((i - 2, j + 1))
        if (i + 2) <= 9 and not map[i + 1][j]:
            if (j - 1) >= 0:
                potential_horse_moves.append((i + 2, j - 1))
            if (j + 1) <= 8:
                potential_horse_moves.append((i + 2, j + 1))
        if (j + 2) <= 8 and not map[i][j + 1]:
            if (i - 1) >= 0:
                potential_horse_moves.append((i - 1, j + 2))
            if (i + 1) <= 9:
                potential_horse_moves.append((i + 1, j + 2))
        if (j - 2) >= 0 and not map[i][j - 1]:
            if (i - 1) >= 0:
                potential_horse_moves.append((i - 1, j - 2))
            if (i + 1) <= 9:
                potential_horse_moves.append((i + 1, j - 2))
        for move in potential_horse_moves:
            if not map[move[0]][move[1]] or map[move[0]][move[1]].player != self.player:
                moves.append((move[0], move[1]))

        return moves


class Elephant(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_elephant.png"
        else:
            self.image = "./images/red_elephant.png"

    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]

        if self.player == Player.BLACK:
            elephant_moves = [(0, 2), (2, 0), (4, 2),
                              (2, 4), (0, 6), (2, 8), (4, 6)]
        else:
            elephant_moves = [(9, 2), (7, 0), (7, 4),
                              (5, 2), (9, 6), (7, 8), (5, 6)]

        moves = []
        potential_elephant_moves = [
            (i - 2, j - 2), (i - 2, j + 2), (i + 2, j - 2), (i + 2, j + 2)]
        elephant_blocks = [
            (i - 1, j - 1), (i - 1, j + 1), (i + 1, j - 1), (i + 1, j + 1)]
        for k in range(len(potential_elephant_moves)):      #因为象的移动位置为固定的点，故直接遍历这些位置可以，士，帅同理
            if (potential_elephant_moves[k] in elephant_moves and map[potential_elephant_moves[k][0]][potential_elephant_moves[k][1]] and map[potential_elephant_moves[k][0]][potential_elephant_moves[k][1]].player != self.player) or (potential_elephant_moves[k] in elephant_moves and not map[potential_elephant_moves[k][0]][potential_elephant_moves[k][1]]):
                if not map[elephant_blocks[k][0]][elephant_blocks[k][1]]:
                    moves.append(
                        (potential_elephant_moves[k][0], potential_elephant_moves[k][1]))

        return moves


class Advisor(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_advisor.png"
        else:
            self.image = "./images/red_advisor.png"

    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]

        if self.player == Player.BLACK:
            advisor_moves = [(0, 3), (0, 5), (1, 4), (2, 3), (2, 5)]
        else:
            advisor_moves = [(9, 3), (9, 5), (8, 4), (7, 3), (7, 5)]

        moves = []
        potential_advisor_moves = [
            (i - 1, j - 1), (i - 1, j + 1), (i + 1, j - 1), (i + 1, j + 1)]
        for move in potential_advisor_moves:
            if (move in advisor_moves and map[move[0]][move[1]] and map[move[0]][move[1]].player != self.player) or(move in advisor_moves and not map[move[0]][move[1]]):
                moves.append((move[0], move[1]))

        return moves


class Cannon(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_cannon.png"
        else:
            self.image = "./images/red_cannon.png"

    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]

        moves = []
        # 向下
        t = 1
        f = 0    #判断有无炮架子
        while (i + t) <= 9:
            if not map[i + t][j]:
                if f == 0:
                    moves.append((i + t, j))
            elif map[i + t][j].player != self.player:
                if f == 1:
                    moves.append((i + t, j))
                    break
                else:
                    f += 1
            elif map[i + t][j].player == self.player:
                f += 1
            t += 1

        # 向上
        t = 1
        f = 0
        while (i - t) >= 0:
            if not map[i - t][j]:
                if f == 0:
                    moves.append((i - t, j))
            elif map[i - t][j].player != self.player:
                if f == 1:
                    moves.append((i - t, j))
                    break
                else:
                    f += 1
            elif map[i - t][j].player == self.player:
                f += 1
            t += 1

        # 向右
        t = 1
        f = 0
        while (j + t) <= 8:
            if not map[i][j + t]:
                if f == 0:
                    moves.append((i, j + t))
            elif map[i][j + t].player != self.player:
                if f == 1:
                    moves.append((i, j + t))
                    break
                else:
                    f += 1
            elif map[i][j + t].player == self.player:
                f += 1
            t += 1

        # 向左
        t = 1
        f = 0
        while (j - t) >= 0:
            if not map[i][j - t]:
                if f == 0:
                    moves.append((i, j - t))
            elif map[i][j - t].player != self.player:
                if f == 1:
                    moves.append((i, j - t))
                    break
                else:
                    f += 1
            elif map[i][j - t].player == self.player:
                f += 1
            t += 1

        return moves


class General(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_general.png"
        else:
            self.image = "./images/red_general.png"

    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]

        moves = []
        if self.player == Player.BLACK:
            general_moves = [(0, 3), (0, 4), (0, 5), (1, 3),
                             (1, 4), (1, 5), (2, 3), (2, 4), (2, 5)]
        else:
            general_moves = [(9, 3), (9, 4), (9, 5), (8, 3),
                             (8, 4), (8, 5), (7, 3), (7, 4), (7, 5)]

        potential_general_moves = [
            (i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)]
        for move in potential_general_moves:
            if (move in general_moves and map[move[0]][move[1]] and map[move[0]][move[1]].player != self.player) or (move in general_moves and not map[move[0]][move[1]]):
                moves.append((move[0], move[1]))
        t = 1
        if self.player == Player.BLACK:
            while (i + t) <= 9:
                if not map[i + t][j]:
                    pass
                if map[i + t][j]:
                    if isinstance(map[i + t][j], General) and map[i + t][j].player != self.player:
                        moves.append((i + t, j))
                        break
                    else:
                        break
                t += 1
        else:
            while (i - t) <= 9:
                if not map[i - t][j]:
                    pass
                if map[i - t][j]:
                    if isinstance(map[i - t][j], General) and map[i - t][j].player != self.player:
                        moves.append((i - t, j))
                        break
                    else:
                        break
                t += 1

        return moves


class Soldier(Attacker):
    def __init__(self, player, address) -> None:
        super().__init__(player, address)
        if self.player == Player.BLACK:
            self.image = "./images/black_soldier.png"
        else:
            self.image = "./images/red_soldier.png"
    #兵分红黑，即红兵只能上走，黑兵只能下走
    def potential_moves(self, map):
        i = self.address[0]
        j = self.address[1]

        moves = []
        if self.player == Player.RED:
            if (i - 1) >= 0:
                if not map[i - 1][j]:
                    moves.append((i - 1, j))
                if map[i - 1][j]:
                    if map[i - 1][j].player != self.player:
                        moves.append((i - 1, j))
            if i <= 4:
                if (j - 1) >= 0:
                    if not map[i][j - 1]:
                        moves.append((i, j - 1))
                    if map[i][j - 1]:
                        if map[i][j - 1].player != self.player:
                            moves.append((i, j - 1))
                if (j + 1) <= 8:
                    if not map[i][j + 1]:
                        moves.append((i, j + 1))
                    if map[i][j + 1]:
                        if map[i][j + 1].player != self.player:
                            moves.append((i, j + 1))
        else:
            if (i + 1) <= 9:
                if not map[i +1][j]:
                    moves.append((i + 1, j))
                if map[i + 1][j]:
                    if map[i + 1][j].player != self.player:
                        moves.append((i + 1, j))
            if i >= 5:
                if (j - 1) >= 0:
                    if not map[i][j - 1]:
                        moves.append((i, j - 1))
                    if map[i][j - 1]:
                        if map[i][j - 1].player != self.player:
                            moves.append((i, j - 1))
                if (j + 1) <= 8:
                    if not map[i][j + 1]:
                        moves.append((i, j + 1))
                    if map[i][j + 1]:
                        if map[i][j + 1].player != self.player:
                            moves.append((i, j + 1))
        return moves
