# 导入pygame
import pygame
# from game_screen import *

# 初始化
pygame.init()

# 初始化字体
font_name = pygame.font.match_font("fangsong")
font = pygame.font.Font(font_name, 30)


# 游戏状态枚举
class GameState:
    START = 0
    GAME = 1
    SETTINGS = 2
    SPECIAL=3


# 定义屏幕参数常量
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720


# 定义颜色常量
WHITE = "0xFFFFFF"
BLACK = "0x000000"
RED = "0xFF0000"
GREEN = "0x00FF00"
BLUE = "0x0000FF"


# 定义文字字典库
class Language:
    def __init__(self):
        self.current_language = "English"
        self.texts = {
            "English": {
                "start": "Start",
                "language set": "Language: English",
                "go to setting": "Settings",
                "return to start": "Return to Start",
                "red player's turn": "Red Player's Turn",
                "black player's turn": "Black Player's Turn",
                "checkmate": "CHECKMATE",
                "red player won": "Red Player Won!",
                "black player won": "Black Player Won!",
                "wanna play again": "Wanna play again?",
                "yes": "yes",
                "no": "no",
                "Wanning":"Wanning",
                "Wanning Chinese Chess":"Wanning Chinese Chess"
            },
            "Chinese": {
                "start": "开始",
                "language set": "语言: 中文",
                "go to setting": "设置",
                "return to start": "返回",
                "red player's turn": "红方回合",
                "black player's turn": "黑方回合",
                "checkmate": "将军！",
                "red player won": "红方获胜！",
                "black player won": "黑方获胜！",
                "wanna play again": "再来一局?",
                "yes": "是？",
                "no": "否",
                "Wanning":"万宁",
                "Wanning Chinese Chess":"万宁象棋"
            }
    }

    # 定义获取对应语言的函数
    def get_text(self, key):
        return self.texts[self.current_language][key]


# 定义开始界面类
class StartScreen:
    def __init__(self):
        self.button_width = 400
        self.button_height = 100
        self.button_spacing = 20
        # 两个按钮之间的垂直间隔

        # 计算按钮位置，使其水平居中
        self.start_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width) // 2,
            SCREEN_HEIGHT //3,
            self.button_width,
            self.button_height
        )
        self.settings_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width) // 2,
            SCREEN_HEIGHT // 3 * 2,
            self.button_width,
            self.button_height
        )


        # self.special_button_rect = pygame.Rect(
        #     (SCREEN_WIDTH - self.button_width) // 2,
        #     SCREEN_HEIGHT//7,
        #     self.button_width,
        #     self.button_height
        # )

    def handle_events(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.start_button_rect.collidepoint(event.pos):
                return GameState.GAME
            elif self.settings_button_rect.collidepoint(event.pos):
                return GameState.SETTINGS
            # elif self.special_button_rect.collidepoint(event.pos):
            #     return GameState.SPECIAL
                

    def render(self, screen, language_manager):
        screen.fill(WHITE)
        # 加载背景图片
        self.background_image = pygame.image.load("./images/background.png")
        screen.blit(self.background_image, (0, 0))

        pygame.draw.rect(screen, BLACK, self.start_button_rect)
        start_text = font.render(language_manager.get_text("start"), True, WHITE)
        start_text_rect = start_text.get_rect(
            center=self.start_button_rect.center)
        screen.blit(start_text, start_text_rect)

        pygame.draw.rect(screen, BLACK, self.settings_button_rect)
        settings_text = font.render(
            language_manager.get_text("go to setting"), True, WHITE)
        settings_text_rect = settings_text.get_rect(
            center=self.settings_button_rect.center)
        screen.blit(settings_text, settings_text_rect)


        # pygame.draw.rect(screen, BLACK, self.special_button_rect)
        # special_text = font.render(language_manager.get_text("Wanning"), True, WHITE)
        # special_text_rect = special_text.get_rect(
        #     center=self.special_button_rect.center)
        # screen.blit(special_text, special_text_rect)


# 定义设置界面类
class SettingsScreen:
    def __init__(self):
        self.button_width = 400
        self.button_height = 100
        self.button_spacing = 20  # 两个按钮之间的垂直间隔

        # 计算按钮位置，使其在屏幕水平和垂直方向上都居中
        self.language_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width) // 2,
            SCREEN_HEIGHT // 3,
            self.button_width,
            self.button_height
        )

        self.return_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width) // 2,
            SCREEN_HEIGHT // 3 * 2,
            self.button_width,
            self.button_height
        )
        # self.special_button_rect = pygame.Rect(
        #     (SCREEN_WIDTH - self.button_width) // 2,
        #     SCREEN_HEIGHT//7,
        #     self.button_width,
        #     self.button_height
        # )

    def handle_events(self, event, language_manager):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.language_button_rect.collidepoint(event.pos):
                if language_manager.current_language == "English":
                    language_manager.current_language = "Chinese"
                else:
                    language_manager.current_language = "English"
            elif self.return_button_rect.collidepoint(event.pos):
                return GameState.START

    def render(self, screen, language_manager):
        screen.fill(WHITE)
        # 加载背景图片
        self.background_image = pygame.image.load("./images/background.png")
        screen.blit(self.background_image, (0, 0))

        pygame.draw.rect(screen, BLACK, self.language_button_rect)
        text = font.render(language_manager.get_text(
            "language set"), True, WHITE)
        text_rect = text.get_rect(center=self.language_button_rect.center)
        screen.blit(text, text_rect)

        pygame.draw.rect(screen, BLACK, self.return_button_rect)
        return_text = font.render(
            language_manager.get_text("return to start"), True, WHITE)
        return_rect = return_text.get_rect(
            center=self.return_button_rect.center)
        screen.blit(return_text, return_rect)
        





