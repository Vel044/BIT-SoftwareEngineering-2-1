# 导入pygame和copy用于深拷贝
import pygame
import copy
import sys
import random
import threading
# 导入宏定义和棋子
from start_and_setting import *
from attacker import *


# 初始化
pygame.init()



# 初始化字体
font_name = pygame.font.match_font("fangsong")
font = pygame.font.Font(font_name, 30)


# 俩图片
dot = pygame.image.load("./images/move.png")
active = pygame.image.load("./images/active.png")



global_variable = 0

def update_global_variable():
    # 使用global关键字声明全局变量
    global global_variable
    global_variable += 1

# 这是各个点位
board = [
    [
        (36, 30),
        (109, 30),
        (182, 30),
        (255, 30),
        (327, 30),
        (399, 30),
        (472, 30),
        (545, 30),
        (618, 30),
    ],
    [
        (36, 94),
        (109, 94),
        (182, 94),
        (255, 94),
        (327, 94),
        (399, 94),
        (472, 94),
        (545, 94),
        (618, 94),
    ],
    [
        (36, 158),
        (109, 158),
        (182, 158),
        (255, 158),
        (327, 158),
        (399, 158),
        (472, 158),
        (545, 158),
        (618, 158),
    ],
    [
        (36, 222),
        (109, 222),
        (182, 222),
        (255, 222),
        (327, 222),
        (399, 222),
        (472, 222),
        (545, 222),
        (618, 222),
    ],
    [
        (36, 286),
        (109, 286),
        (182, 286),
        (255, 286),
        (327, 286),
        (399, 286),
        (472, 286),
        (545, 286),
        (618, 286),
    ],
    [
        (36, 353),
        (109, 353),
        (182, 353),
        (255, 353),
        (327, 353),
        (399, 353),
        (472, 353),
        (545, 353),
        (618, 353),
    ],
    [
        (36, 417),
        (109, 417),
        (182, 417),
        (255, 417),
        (327, 417),
        (399, 417),
        (472, 417),
        (545, 417),
        (618, 417),
    ],
    [
        (36, 481),
        (109, 481),
        (182, 481),
        (255, 481),
        (327, 481),
        (399, 481),
        (472, 481),
        (545, 481),
        (618, 481),
    ],
    [
        (36, 545),
        (109, 545),
        (182, 545),
        (255, 545),
        (327, 545),
        (399, 545),
        (472, 545),
        (545, 545),
        (618, 545),
    ],
    [
        (36, 609),
        (109, 609),
        (182, 609),
        (255, 609),
        (327, 609),
        (399, 609),
        (472, 609),
        (545, 609),
        (618, 609),
    ],
]

# 红方士象将可以走的位置
red_advisor_moves = [(9, 3), (9, 5), (8, 4), (7, 3), (7, 5)]
red_elephant_moves = [(9, 2), (7, 0), (7, 4), (5, 2), (9, 6), (7, 8), (5, 6)]
red_general_moves = [
    (9, 3),
    (9, 4),
    (9, 5),
    (8, 3),
    (8, 4),
    (8, 5),
    (7, 3),
    (7, 4),
    (7, 5),
]

# 黑方士象将可以走的位置
black_advisor_moves = [(0, 3), (0, 5), (1, 4), (2, 3), (2, 5)]
black_elephant_moves = [(0, 2), (2, 0), (4, 2), (2, 4), (0, 6), (2, 8), (4, 6)]
black_general_moves = [
    (0, 3),
    (0, 4),
    (0, 5),
    (1, 3),
    (1, 4),
    (1, 5),
    (2, 3),
    (2, 4),
    (2, 5),
]


red_general = General(Player.RED, (9, 4))
black_general = General(Player.BLACK, (0, 4))

# 原始棋盘
original_map = [
    [
        Chariot(Player.BLACK, (0, 0)),
        Horse(Player.BLACK, (0, 1)),
        Elephant(Player.BLACK, (0, 2)),
        Advisor(Player.BLACK, (0, 3)),
        General(Player.BLACK, (0, 4)),
        Advisor(Player.BLACK, (0, 5)),
        Elephant(Player.BLACK, (0, 6)),
        Horse(Player.BLACK, (0, 7)),
        Chariot(Player.BLACK, (0, 8)),
    ],
    ["", "", "", "", "", "", "", "", ""],
    [
        "",
        Cannon(Player.BLACK, (2, 1)),
        "",
        "",
        "",
        "",
        "",
        Cannon(Player.BLACK, (2, 7)),
        "",
    ],
    [
        Soldier(Player.BLACK, (3, 0)),
        "",
        Soldier(Player.BLACK, (3, 2)),
        "",
        Soldier(Player.BLACK, (3, 4)),
        "",
        Soldier(Player.BLACK, (3, 6)),
        "",
        Soldier(Player.BLACK, (3, 8)),
    ],
    ["", "", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", "", ""],
    [
        Soldier(Player.RED, (6, 0)),
        "",
        Soldier(Player.RED, (6, 2)),
        "",
        Soldier(Player.RED, (6, 4)),
        "",
        Soldier(Player.RED, (6, 6)),
        "",
        Soldier(Player.RED, (6, 8)),
    ],
    [
        "",
        Cannon(Player.RED, (7, 1)),
        "",
        "",
        "",
        "",
        "",
        Cannon(Player.RED, (7, 7)),
        "",
    ],
    ["", "", "", "", "", "", "", "", ""],
    [
        Chariot(Player.RED, (9, 0)),
        Horse(Player.RED, (9, 1)),
        Elephant(Player.RED, (9, 2)),
        Advisor(Player.RED, (9, 3)),
        General(Player.RED, (9, 4)),
        Advisor(Player.RED, (9, 5)),
        Elephant(Player.RED, (9, 6)),
        Horse(Player.RED, (9, 7)),
        Chariot(Player.RED, (9, 8)),
    ],
]

def play_music():
    # 创建音频设备
    pygame.mixer.init()

    # 设置音乐文件路径
    music_file = "./music/将军.mp3"

    # 加载音乐文件
    pygame.mixer.music.load(music_file)

    # 播放音乐
    pygame.mixer.music.play()

    # 等待音乐播放完毕
    while pygame.mixer.music.get_busy():
        continue

    # 停止音乐
    pygame.mixer.music.stop()
def play_music2():
    # 创建音频设备
    pygame.mixer.init()

    # 设置音乐文件路径
    music_file = "./music/行棋.mp3"

    # 加载音乐文件
    pygame.mixer.music.load(music_file)

    # 播放音乐
    pygame.mixer.music.play()

    # 等待音乐播放完毕
    while pygame.mixer.music.get_busy():
        continue

    # 停止音乐
    pygame.mixer.music.stop()


def render_game(map, screen):
    """
   初始化游戏窗口。并用棋盘背景填充窗口
。
    """
    # 白底
    screen.fill((255, 255, 255))
    #在画布顶部显示背景图像
    background = pygame.image.load("./images/bg.jpg")
    screen.blit(background, (40, 40))
    # 显示棋子
    for i in range(len(map)):
        for j in range(len(map[0])):
            if map[i][j]:
                screen.blit(
                    pygame.image.load(map[i][j].image),
                    (board[i][j][0] - 16, board[i][j][1] - 16),
                )
    


def move_clicked(moves, position):
    """
    看点的哪步
    """
    for move in moves:
        if dot.get_rect(
            topleft=(board[move[0]][move[1]][0], board[move[0]][move[1]][1])
        ).collidepoint(position):
            return move
        






# 定义游戏界面类


class GameScreen:
    def __init__(self):
        self.button_width = 400
        self.button_height = 100
        self.button_right_spacing = 20
        self.button_spacing = 20  # 两个按钮之间的垂直间隔
        # 计算按钮位置，使其靠右靠下
        self.return_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width - self.button_right_spacing),
            SCREEN_HEIGHT // 3 * 2 - self.button_height - self.button_spacing,
            self.button_width,
            self.button_height,
        )
        self.settings_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width - self.button_right_spacing),
            SCREEN_HEIGHT // 3 * 2,
            self.button_width,
            self.button_height,
        )
        self.special_button_rect = pygame.Rect(
            (SCREEN_WIDTH - self.button_width - self.button_right_spacing),
            SCREEN_HEIGHT // 3 ,
            self.button_width,
            self.button_height,
        )
        # 加载选中和激活的图片
        self.dot = pygame.image.load("./images/move.png")
        self.active = pygame.image.load("./images/active.png")
        self.map = copy.deepcopy(original_map)
        self.turn = 0
        self.second_click = False

    def player(self):
        if (self.turn % 2) == 0:
            player = Player.RED
        else:
            player = Player.BLACK
        return player

    def check_future_checkmate(self, piece, moves, turn, map):
        # 检查是否将军
        legal_moves = []
        for m in moves:
            map1 = copy.deepcopy(map)
            # map1[piece.address[0]][piece.address[1]] = ''
            map1[m[0]][m[1]] = map1[piece.address[0]][piece.address[1]]
            map1[piece.address[0]][piece.address[1]] = '' 
            map1[m[0]][m[1]].move(m)
            
            if not self.checkmate(map1, turn):
                legal_moves.append(m)
        return legal_moves
    
    def general_address(self,map, player):
        for i in map:
            for piece in i:
                if piece:
                    if isinstance(piece, General) and piece.player == player:
                        return piece.address



    def checkmate(self, map, turn):
        # 得到帅/将的位置
        if (turn % 2) == 0:
            address_general = self.general_address(map, Player.RED)
        if (turn % 2) == 1:
            address_general = self.general_address(map, Player.BLACK)
        # 红棋是否被将军
        if (turn % 2) == 0:
            for i in map:
                for piece in i:
                    if piece:
                        if piece.player == Player.BLACK:
                            if address_general in piece.potential_moves(map):
                                return True
        # 黑棋是否被将军
        else:
            for i in map:
                for piece in i:
                    if piece:
                        if piece.player == Player.RED:
                            if address_general in piece.potential_moves(map):
                                return True
        return False


    def end_game(self):
        for i in self.map:
            for piece in i:
                if piece:
                    if piece.player == self.player():
                        moves = piece.potential_moves(self.map)
                        moves = self.check_future_checkmate(
                            piece, moves, self.turn, self.map
                        )
                        if moves:
                            return False
        return True

    def piece_clicked(self, position):
        for i in range(len(self.map)):
            for j in range(len(self.map[0])):
                if self.map[i][j]:
                    if self.map[i][j].player and self.map[i][j].player == self.player():
                        if (
                            pygame.image.load(self.map[i][j].image)
                            .get_rect(
                                topleft=(board[i][j][0] - 16, board[i][j][1] - 16)
                            )
                            .collidepoint(position)
                        ):
                            return self.map[i][j]

    def end_game_question(self, events, screen, language_manager):
        #结束时询问是否进行下一盘
        if self.player() == Player.RED:
            text_surface = font.render(language_manager.get_text("black player won"), False, (0, 0, 0))
            screen.blit(text_surface, (700, 40))
        else:
            text_surface = font.render(language_manager.get_text("red player won"), False, (0, 0, 0))
            screen.blit(text_surface, (710, 40))
        text_surface1 = font.render(language_manager.get_text("wanna play again"), False, (0, 0, 0))
        yes = font.render(language_manager.get_text("yes"), False, (0, 0, 0))
        no = font.render(language_manager.get_text("no"), False, (0, 0, 0))
        screen.blit(text_surface1, (700, 80))
        screen.blit(yes, (725, 130))
        screen.blit(no, (875, 130))
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if yes.get_rect(topleft=(735, 130)).collidepoint(event.pos):
                    return True
                if no.get_rect(topleft=(875, 130)).collidepoint(event.pos):
                    sys.exit()
    def bt(self):
        #万宁象棋
        general_address=self.general_address(self.map,self.player())
        x,y=self.general_address(self.map,self.player())
        for i in range(x-1,x+2):
            for j in range(y-1,y+2):
                if i>=0 and i<=9 and j>=0 and j<=8 and (not self.map[i][j]):
                    piece_types = [Chariot, Horse, Cannon]
                    random_piece_type = random.choice(piece_types)
                    self.map[i][j] = random_piece_type(self.player(), (i, j))


    #按钮点击效果
    def handle_events(self, event, screen):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.return_button_rect.collidepoint(event.pos):
                return GameState.START
            elif self.settings_button_rect.collidepoint(event.pos):
                return GameState.SETTINGS
            elif self.special_button_rect.collidepoint(event.pos):
                self.bt()


    def render(self, screen, language_manager, event):
        screen.fill(WHITE)
        # 加载背景图片
        self.background = pygame.image.load("./images/bg.jpg")
        screen.blit(self.background, (40, 40))
        
        render_game(self.map, screen)

        if event.type == pygame.MOUSEBUTTONDOWN:
            self.position = event.pos
            #第一次选中棋子
            if self.piece_clicked(self.position):
                render_game(self.map, screen)
                self.second_click = True
                self.choosed_piece = self.piece_clicked(self.position)
                moves = self.choosed_piece.potential_moves(self.map)
                self.possible_moves = self.check_future_checkmate(
                    self.choosed_piece, moves, self.turn, self.map
                )
                screen.blit(
                    self.active,
                    (
                        board[self.choosed_piece.address[0]][
                            self.choosed_piece.address[1]
                        ][0]
                        - 22,
                        board[self.choosed_piece.address[0]][
                            self.choosed_piece.address[1]
                        ][1]
                        - 22,
                    ),
                )
                for move in moves:
                    screen.blit(
                        self.dot,
                        (
                            board[move[0]][move[1]][0] - 2,
                            board[move[0]][move[1]][1] - 2,
                        ),
                    )
            elif self.second_click and move_clicked(self.possible_moves, self.position):
                #判断落子
                music_thread = threading.Thread(target=play_music2)
                music_thread.start()
                move = move_clicked(self.possible_moves, self.position)
                self.map[self.choosed_piece.address[0]][self.choosed_piece.address[1]] = ''
                self.choosed_piece.move(move)
                self.map[self.choosed_piece.address[0]][self.choosed_piece.address[1]] = self.choosed_piece
                render_game(self.map, screen)
                screen.blit(
                    dot,
                    (
                        board[self.choosed_piece.address[0]][
                            self.choosed_piece.address[1]
                        ][0]
                        - 2,
                        board[self.choosed_piece.address[0]][
                            self.choosed_piece.address[1]
                        ][1]
                        - 2,
                    ),
                )
                screen.blit(
                    active,
                    (board[move[0]][move[1]][0] - 22, board[move[0]][move[1]][1] - 22),
                )

                self.second_click = False
                self.turn += 1
            else:
                render_game(self.map, screen)
                self.second_click = False

            if self.checkmate(self.map, self.turn):
                update_global_variable()
                
                if global_variable%2 == 1:
                    music_thread = threading.Thread(target=play_music)
                    music_thread.start()

                if self.player() == Player.RED:
                    m, n = self.general_address(self.map, Player.RED)
                if self.player() == Player.BLACK:
                    m, n = self.general_address(self.map, Player.BLACK)
                screen.blit(active, (board[m][n][0] - 22, board[m][n][1] - 22))
                text_checkmate = font.render(language_manager.get_text("checkmate"), False, (0, 0, 0))
                screen.blit(text_checkmate, (730, 310))

        # 显示游玩顺序
        if self.player() == Player.RED and not self.end_game():
            text_turn = font.render(language_manager.get_text("red player's turn"), False, (0, 0, 0))
            screen.blit(text_turn, (730, 100))
        elif self.player() == Player.BLACK and not self.end_game():
            text_turn = font.render(language_manager.get_text("black player's turn"), False, (0, 0, 0))
            screen.blit(text_turn, (720, 100))
        # 显示两个按钮
        pygame.draw.rect(screen, BLACK, self.settings_button_rect)
        pygame.draw.rect(screen, BLACK, self.return_button_rect)
        pygame.draw.rect(screen, BLACK, self.settings_button_rect)
        pygame.draw.rect(screen, BLACK, self.special_button_rect)
        settings_text = font.render(
            language_manager.get_text("go to setting"), True, WHITE
        )
        settings_text_rect = settings_text.get_rect(
            center=self.settings_button_rect.center
        )
        screen.blit(settings_text, settings_text_rect)
        return_text = font.render(
            language_manager.get_text("return to start"), True, WHITE
        )
        return_text_rect = return_text.get_rect(center=self.return_button_rect.center)
        screen.blit(return_text, return_text_rect)

        special_text = font.render(
            language_manager.get_text("Wanning Chinese Chess"), True, WHITE
        )
        special_text_rect = special_text.get_rect(
            center=self.special_button_rect.center
        )
        screen.blit(special_text, special_text_rect)