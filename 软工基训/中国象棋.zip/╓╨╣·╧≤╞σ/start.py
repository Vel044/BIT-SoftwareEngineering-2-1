# 导入pygame和sys
import pygame
import sys

# 导入各个界面的模块
from game_screen import *
from start_and_setting import *
from attacker import *



# 初始化语言设置模块，默认为英文
language_manager = Language()


# 游戏运行的主函数
def main():
    # 设置标题
    pygame.display.set_caption(
        "神龙破天：乱世棋王 (Dragon Fury: Chess Legend of Havoc)")

    # 设置图像帧率
    FPS = 60
    clock = pygame.time.Clock()  # 创建时钟对象

    # 初始化三个界面
    start_screen = StartScreen()
    game_screen = GameScreen()
    settings_screen = SettingsScreen()

    current_state = GameState.START

    current_screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    while True:
        if game_screen.end_game():

            # 重开或退出
            if game_screen.end_game_question( pygame.event.get(),current_screen, language_manager):
                game_screen.map = copy.deepcopy(original_map)
                game_screen.turn = 0
                render_game(game_screen.map, current_screen)
                continue

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # 若检测到退出，先终止pygame，再调用sys.exit()
                pygame.quit()
                sys.exit()

            if current_state == GameState.START:
                next_state = start_screen.handle_events(event)
            elif current_state == GameState.GAME:
                next_state = game_screen.handle_events(event,current_screen)
            elif current_state == GameState.SETTINGS:
                 next_state = settings_screen.handle_events(
                    event, language_manager)
            # elif current_state==GameState.SPECIAL:
            #     bt()

            if next_state is not None:
                current_state = next_state

            if current_state == GameState.START:
                start_screen.render(current_screen, language_manager)
            elif current_state == GameState.GAME:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    game_screen.render(current_screen, language_manager,event)
            elif current_state == GameState.SETTINGS:
                settings_screen.render(current_screen, language_manager)

        pygame.display.flip()  # 更新屏幕
        clock.tick(FPS)  # 按照FPS的频率来刷新界面



if __name__ == "__main__":
    main()