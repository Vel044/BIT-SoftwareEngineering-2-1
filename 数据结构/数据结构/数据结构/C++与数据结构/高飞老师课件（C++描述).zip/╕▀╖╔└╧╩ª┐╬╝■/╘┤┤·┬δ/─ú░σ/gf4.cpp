#include "iostream.h"
template<class t1,class t2>
class Rectangle
{
  private:
     t1 width;
	 t2 height;
  public:
     Rectangle(t1 a, t2 b)
	 {
	   width=a;
       height=b;
	 }
     void show()
	 {
	   cout<<"width="<<width<<"  height="<<height<<endl;
	  }
	 t2 area();
};
template<class t1, class t2>
t2 Rectangle<t1,t2>::area()
{
  return width*height;
}
void main()
{
  int ni=5,nj=8;
  double di=56.89,dj=23.3;
  Rectangle<int,int> ob1(ni,nj);
  ob1.show();
  cout<<"area="<<ob1.area()<<endl;
  Rectangle<int,double> ob2(ni,dj);
  ob2.show();
  cout<<"area="<<ob2.area()<<endl;
}