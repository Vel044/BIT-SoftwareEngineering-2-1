#include "iostream.h"
#include "string.h"
template <class T1>
T1 max(T1 a,T1 b)
{
  return (a>b)?a:b;
}
template <class T1>
T1 max(T1 a,T1 b,T1 c)
{
  T1 t;
  t=(a>b)?a:b;
  return (t>c)?t:c;
}
char *max(char *a, char *b)
{
	return strcmp(a,b)>0?a:b;
}
void main()
{
  int x=0,y=20,max1;
  double a=10.3,b=21.7,c=14.5,max2;
  char *str2="abc",*str1="wyz",*max3;
  max1=max(x,y);
  max2=max(a,b,c);
  cout<<"("<<x<<","<<y<<")�д���Ϊ��"<<max1<<endl;
  cout<<"("<<a<<","<<b<<","<<c<<")�д���Ϊ��"<<max2<<endl;
  max3=max(str1,str2);
  cout<<"("<<str1<<","<<str2<<")�д���Ϊ��"<<max3<<endl;
}