#include <iostream.h>
template <class t1,class t2>	                 //sort����ģ��
void min(t1 x, t2 y)
{
  if(x<y) cout<<"Min="<<x;
  else cout<<"Min="<<y;
}
void main()
{
  int n1=2,n2=10;
  double d1=1.5,d2=5.6;
  min(n1,n2);cout<<endl;
  min(d1,d2);cout<<endl;
 }
