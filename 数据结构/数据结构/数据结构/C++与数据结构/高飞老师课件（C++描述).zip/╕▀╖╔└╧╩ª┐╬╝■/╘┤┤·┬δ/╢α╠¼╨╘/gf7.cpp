#include "iostream.h"
#include "string.h"
class cstring
{
  private:
     int m;
	 char *pstr;
  public:
     cstring(char *s)
	 {
	   m=strlen(s);
	   pstr=new char[m+1];
	   strcpy(pstr,s);
	 }
	 ~cstring(){delete[]pstr;}
	 cstring &operator =(cstring &s)
	 {
	   delete[]pstr;
	   pstr=new char[strlen(s.pstr)+1];
       strcpy(pstr,s.pstr);
	   return *this;
	 }
	 void print()
	 {cout<<pstr<<endl;}
};
void main()
{
  cstring p1("Hello");
  cstring p2("How are you");
  p2=p1;
  cout<<"p2:";
  p2.print();
  cout<<"p1:";
  p1.print();
}