#include <iostream.h>
class add
{
   private:
      int a,b,c;
   public:
      add()
	  {
	    a=b=c=0;
	  }
	  add(int x,int y)
      {
	    a=x;b=y;c=0;
	  }
      add(int x,int y,int z)
      {
	    a=x;b=y;c=z;
	  }
	  void print()
	  {
	    cout<<a+b+c<<endl;
	  }
};
void main()
{
  add a1();
  add a2(1,2);
  add a3(1,2,3);
  a2.print();
  a3.print();

}