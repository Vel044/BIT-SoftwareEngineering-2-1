#include "iostream.h"
class complex
{
  private: 
     double rel,img;
  public:
     complex(){ rel=0; img=0;}
     complex(double r, double i){ rel=r; img=i;}
     complex  operator+(complex com);
	 void print()
	 {
	   cout<<rel;
	   if(img>0)cout<<"+";
       if(img!=0)cout<<img<<"i"<<endl;
	 }
};
complex complex::operator+(complex com)
{
  complex t;
  t.rel=rel+com.rel;
  t.img=img+com.img;
  return t;
}
void main()
{
  complex c1(1.5,2.6),c2(3.6,4.8);
  complex a1,a2;
  a1=c1.operator+(c2);
  a1.print();
  a2=c1+c2;
  a2.print();
}