#include<iostream.h>
class complex	               
{
   public:	                   
	   complex() {rel=0; img=0;}
	   complex(double r,double i) { rel=r; img=i; }	
	   friend complex operator + (complex com1,complex  com2);	
	   void print()
	   {
	     cout<<rel;
		 if (img>0)cout<<"+";
	     if (img!=0)cout<<img<<"i"<<endl;
	   }	   
  private:	            
	  double rel;
	  double img;
};		
complex operator +(complex com1,complex com2)	
{	  
	complex t;
	t.rel=com1.rel+com2.rel;
    t.img=com1.img+com2.img;
    return t;
}
void main()     
{	complex c1(1.5,2.6),c2(3.6,4.8);  
    complex a1,a2;
	a1=c1+c2;	                       
    a1.print();
	a2=operator +(c1,c2);
	a2.print();
 }
