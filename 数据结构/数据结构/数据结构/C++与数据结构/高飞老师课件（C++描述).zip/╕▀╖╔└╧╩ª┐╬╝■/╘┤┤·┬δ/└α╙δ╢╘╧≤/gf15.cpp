#include<iostream.h>
void swap1(int x,int y)
{
  int temp;
  temp=x;
  x=y;
  y=temp;
}
void swap2(int *x,int *y)
{
  int temp;
  temp=*x;
  *x=*y;
  *y=temp;
}
void swap3(int &x,int &y)
{
  int temp;
  temp=x;
  x=y;
  y=temp;
}
int main()
{
  void swap3(int &,int &);
  int a,b;
  a=10;
  b=20;
  cout<<"����ǰ��a="<<a<<",b="<<b<<endl;
  swap3(a,b);
  cout<<"������a="<<a<<",b="<<b<<endl;
  return 0;
}